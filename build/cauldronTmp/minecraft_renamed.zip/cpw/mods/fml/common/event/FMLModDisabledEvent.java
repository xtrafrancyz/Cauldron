package cpw.mods.fml.common.event;

public class FMLModDisabledEvent extends FMLEvent {
}