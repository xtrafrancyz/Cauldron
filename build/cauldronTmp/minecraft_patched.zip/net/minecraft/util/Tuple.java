package net.minecraft.util;

public class Tuple
{
    private Object first;
    private Object second;
    private static final String __OBFID = "CL_00001502";

    public Tuple(Object p_i1555_1_, Object p_i1555_2_)
    {
        this.first = p_i1555_1_;
        this.second = p_i1555_2_;
    }

    public Object getFirst()
    {
        return this.first;
    }

    public Object getSecond()
    {
        return this.second;
    }
}