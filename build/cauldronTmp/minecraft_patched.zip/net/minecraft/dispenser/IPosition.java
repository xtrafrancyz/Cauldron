package net.minecraft.dispenser;

public interface IPosition
{
    double getX();

    double getY();

    double getZ();
}