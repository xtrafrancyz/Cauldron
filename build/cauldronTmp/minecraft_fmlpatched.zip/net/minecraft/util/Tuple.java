package net.minecraft.util;

public class Tuple
{
    private Object field_76343_a;
    private Object field_76342_b;
    private static final String __OBFID = "CL_00001502";

    public Tuple(Object p_i1555_1_, Object p_i1555_2_)
    {
        this.field_76343_a = p_i1555_1_;
        this.field_76342_b = p_i1555_2_;
    }

    public Object func_76341_a()
    {
        return this.field_76343_a;
    }

    public Object func_76340_b()
    {
        return this.field_76342_b;
    }
}