package net.minecraft.dispenser;

public interface IPosition
{
    double func_82615_a();

    double func_82617_b();

    double func_82616_c();
}